 <?php
	
	if(!isset($_SESSION)){
		session_start();
	}
	
	//Destory Session
	session_unset();
	session_destroy();
	header('Location: index.php');
	exit;
	
	setcookie(session_name(),'',time()-3600);

?>