<?php
    // Include DB connect file
    require_once "dbConnect.php";
    require_once "header.php";

    if(!isset($_SESSION)){
      session_start();
      }
?>

<?php
  // Insert PHP code
  if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    //Variable Filter
    $user_name      = $_SESSION['username'];
    $total_amount   = filter_input(INPUT_POST, "total_amount", FILTER_SANITIZE_NUMBER_FLOAT);
    $quantity       = filter_input(INPUT_POST, "quantity", FILTER_SANITIZE_NUMBER_INT);
    $status         = filter_input(INPUT_POST, "status", FILTER_VALIDATE_BOOLEAN);

    //Insert Query
    $sql = ("INSERT INTO redpacket(`user_name`,`total_amount`,`quantity`,`status`)VALUES('$user_name','$total_amount','$quantity','$status')");
    $result = mysqli_query($conn,$sql);

    
    if($result){
    // Alert of error msg
    echo"<script>alert('Sent Red Packet successfully');</script>";
    }
    else{
      echo"<script>alert('Failed to send!');</script>";
    }
  }

?>

<body class="bgimg">

    <!--Login and Username-->
    <?php if( isset($_SESSION['username']) && !empty($_SESSION['username']) )
    {
    ?>
          <a href="logout.php" class="w3-button w3-grey w3-section w3-right">Logout</a>
          <label class="w3-right name">Hi , <?php if($_SESSION['isLogin']): ?><?php echo $_SESSION['username']; ?><?php endif; ?></label>
    <?php }else{ ?>
         <a href="user.php" class="w3-button w3-grey w3-section w3-right" type="button">Login</a>
    <?php } ?>
    
 
      
  <!--Title-->
  <header class="w3-container w3-left w3-padding-48">
  	<h1 class="w3-jumbo w3-animate-top logo-fornt">RED PACKET <i class="fa fa-exchange" aria-hidden="true"></i></h1>
  </header>

  <!-- Button -->
  <div class="w3-container">
      <a class="w3-button w3-grey w3-section btn-send" type="submit" data-toggle="modal" href="#openModal">Send a Red Packet <i class="fa fa-paper-plane" aria-hidden="true"></i></a>
      <a href="GetRedPacket.php" class="w3-button w3-grey w3-section btn-get" type="button">Get a Red Packet <i class="fa fa-get-pocket" aria-hidden="true"></i></a>
  </div>
  
  <!-- Modal Form -->
  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data"> 
    <div id="openModal" class="modal modal-wide fade">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title">Send a Red Packet <img src="image/red-packet-logo.png" alt="" width="28" height="23"></h4>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label> User Name : </label>
              <div class="col-sm-12">
                <input class="form-control" type="textbox" id="user_name" name="user_name" value="<?php echo $_SESSION['username']; ?>" readonly>
              </div>
            </div>
            <div class="form-group">
              <label> Total Amount : </label>
              <div class="col-sm-12">
                <input class="form-control" type="number" id="total_amount" min="0.01" step="0.01" placeholder="0.01 MYR" name="total_amount" value="">
              </div>
            </div>
            <br>
            <div class="form-group">
              <label> Quantity : </label>
              <div class="col-sm-12">
                <input class="form-control" type="textbox" id="quantity" placeholder="Enter Number" name="quantity" value="">
              </div>
            </div>
            <br>
            <br>
            <div class="form-group">
              <div class="col-sm-12">
                <select id="status" name="status" class="form-control">
                  <option value="0">Random</option>
                  <option value="1">Each</option>
                </select> 
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn w3-dark-grey" data-dismiss="modal">Close</button>
            <button type="submit" class="btn w3-orange" id="submit" name="submit">Send</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  </form>
</body>