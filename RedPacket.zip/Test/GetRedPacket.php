<?php
    // Include DB connect file
    require_once "dbConnect.php";
    require_once "header.php";

    if(!isset($_SESSION)){
        session_start();
        }
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])){
        $username   = $_SESSION['username'];
        $total   = filter_input(INPUT_POST, "total", FILTER_SANITIZE_NUMBER_FLOAT);

        $sql = "INSERT INTO transaction(`user_name`,`amount`)VALUES('$username',$total)";
        $result = mysqli_query($conn,$sql);
        if($result){
        //Save inside database
        echo"<script>alert('Add to transaction successfully');</script>";
        }
        else{
            echo"<script>alert('Failed to add!');</script>";
        }
    }
?>

<body class="bgimg-get">

    <!--Login And Username -->
    <?php if( isset($_SESSION['username']) && !empty($_SESSION['username']) )
        {
    ?>
        <a href="logout.php" class="w3-button w3-grey w3-section w3-right">Logout</a>
        <label class="w3-right name2">Hi , <?php if($_SESSION['isLogin']): ?><?php echo $_SESSION['username']; ?><?php endif; ?></label>
    <?php }else{ ?>
       <a href="user.php" class="w3-button w3-grey w3-section w3-right" type="button">Login</a>
    <?php } ?>
  
    <div class="w3-content" style="max-width:1600px">
        <!-- Header -->
        <header class="w3-container w3-center w3-padding-16 w3-light-grey">
            <!--Back index button-->
            <a href="index.php" class="w3-button w3-grey w3-section btn-get w3-left" type="button">Back</a>
        
            <!--Title-->
            <h1 class="w3-xxxlarge">GET A RED PACKET NOW ! <i class="fa fa-arrow-right w3-red" aria-hidden="true"></i> <i class="fa fa-arrow-right w3-red" aria-hidden="true"></i><input type="image" class="imgRedPacket w3-right" src="image/red-packet-header.png" data-toggle="modal" href="#openredModal"/></h1>
            <!-- Modal Form -->
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data"> 
                <div id="openredModal" class="modal modal-wide fade">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Red Packet <img src="image/red-packet-logo.png" alt="" width="28" height="23"></h4>
                      </div>
                      <div class="modal-body back">
                        <h2>Congratulation, <?php echo $_SESSION['username']; ?>!!</h2>
                        <h4>You get the RM <br><input type="text" class="w3-black w3-center" width="20%" name="total" value="<?php $total=(rand(0.01, 100)); echo $total; ?>" /><br>
                        Red Packet!</h4>
                      </div>
                      <div class="modal-footer">
                        <input type="submit" name="submit" class="btn w3-dark-grey" value="Close">
                      </div>
                    </div><!-- /.modal-content -->
                  </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
            </form>
        </header>
        <br>
        <br>
        <h2>RED PACKET REWARDS</h2>
        <br>
        <table class="w3-table w3-striped w3-bordered">
            <thead>
                <tr class="w3-theme">
                   <th>No.</th>
                   <th>User Name</th>
                   <th>Amount</th>
                   <th>Quantity</th>
                   <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
                $query = "SELECT * FROM redpacket";
                $result = mysqli_query($conn,$query);
        
                $i=1;
                while($row = mysqli_fetch_assoc($result))
                {
            ?>
                <tr>
                    <?php $rowID = $row['redpacket_id']; ?>
                    <td><?php echo $i ?></td>
                    <td><?php echo $row['user_name']; ?></td>
                    <td name="total_amount"><?php echo $row['total_amount']; ?></td>
                    <td name="quantity"><?php echo $row['quantity']; ?></td>
                    <td>
                         <button type="button" class="btn w3-red" href="#openModal<?php echo $i ?>" data-postid='"<?php echo $row['redpacket_id'];?>"' data-toggle="modal" id="save">Open</button>

                    </td>
                    <!-- Modal Form -->
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data"> 
                        <div id="openModal<?php echo $i; ?>" class="modal modal-wide2 fade">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title">Red Packet <img src="image/red-packet-logo.png" alt="" width="28" height="23"></h4>
                              </div>
                              <div class="modal-body">
                                <?php
                                    $total=$row['total_amount'];
                                    $num=$row['quantity'];
                                    $min=0.01;
                                    for ($n=1;$n<$num;$n++)
                                    {
                                      $sub_total=($total-($num- $n) * $min)/($num- $n);
                                      $money=mt_rand ($min * 100, $sub_total * 100)/100;
                                      $total=$total- $money;
                                      echo "User ". $n. " receive red packet RM ". $money. ", the balance: RM ". $total."";
                                      echo "<br>";
                                    }
                                    echo "User ". $num. " receive red packet: RM ". $total. ", the balance:RM 0 ";
                                    echo "<br>";  
                                ?>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn w3-dark-grey" data-dismiss="modal">Close</button>
                              </div>
                            </div><!-- /.modal-content -->
                          </div><!-- /.modal-dialog -->
                        </div><!-- /.modal -->
                    </form>
                </tr>
            </tbody>
            <?php $i++; } ?>
        </table>   
    </div>
    <br>
    <br>
    <!--transaction modal-->
    <button type="button" class="w3-button w3-grey w3-section btn-tran w3-left" href="#opentranModal" data-toggle="modal" id="save">View Transaction</button>
    <!-- Modal Form -->
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data"> 
        <div id="opentranModal" class="modal modal-wide fade">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">My Transaction <img src="image/red-packet-logo.png" alt="" width="28" height="23"></h4>
              </div>
              <div class="modal-body">
                <table class="w3-table w3-striped w3-bordered">
                    <thead>
                        <tr class="w3-theme">
                            <th>No.</th>
                           <th>Username</th>
                           <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $query = "SELECT * FROM transaction";
                            $result = mysqli_query($conn,$query);
                    
                            $i=1;
                            while($row = mysqli_fetch_assoc($result))
                            {
                        ?>
                        <tr>
                            <?php $rowID = $row['transaction_id']; ?>
                            <td><?php echo $i ?></td>
                            <td><?php echo $row['user_name']; ?></td>
                            <td><?php echo $row['amount']; ?></td>
                        </tr>
                    </tbody>
                    <?php $i++; } ?>
                </table>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn w3-dark-grey" data-dismiss="modal">Close</button>
              </div>
            </div><!-- /.modal-content -->
          </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
    </form>
</body>