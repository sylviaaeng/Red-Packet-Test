
//Index Modal Form js
$(".modal-wide").on("show.bs.modal", function() {
    var height = $(window).height() - 200;
    $(this).find(".modal-body").css("max-height", height);
 });

//random red packect money
$(function () {
 $("button"). click (function () {
 $.ajax ({
  type:"post",  url:"GetRedPacket.php",  datatype:"json",  beforesend:function () {
  $("#result"). html ("Assigning red packet");
  },  success:function (json) {
  if (json.msg == 1) {
   var str="";
   var res=json.res;
   $.each (res, function (index, array) {
   str +="&p;p<span>" + array ["i"] + "</span>red packet, amount<span>" + array ["money"] + "</span> ;MYR, balance<span>"+ array [" total "] +" Yuan</span></p>";
   });
   $("#result"). html (str);
  } else {
   $("#result"). html ("Data error!");
  }
  }
 });
 });
});
