<?php
    // Include DB connect file
    require_once "dbConnect.php";
    require_once "header.php";
?>
<?php
	if(!isset($_SESSION)){
		session_start();
		}
		
	$confirmation_code=md5(uniqid(rand()));
	
	// register
	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['username'],$_POST['password'])){
		
		$username 	= filter_var(htmlentities($_POST['username'], FILTER_SANITIZE_STRING));
		$random_alpha   = md5(rand());
		$password 	= password_hash($_POST['password'], PASSWORD_DEFAULT);
		

		$sql = "INSERT INTO user(`user_name`,`password`)VALUES('".$_POST['username']."','$password')";
		$result = $conn->query($sql);
		
		if($result)
		{
			echo "<script>alert('REGISTER SUCCESSFULLY');</script>";	
			$_SESSION['isLogin'] = true;
			$_SESSION['username'] = $username;
			header ("Location:index.php");
			exit();
		}
		else
	 	{
			echo "<script>alert('FAILED TO register');</script>";
	 	}
		
	}
?>
<body class="bgimg-login">
	<header class="w3-container w3-center w3-padding-16 w3-light-grey">  	
		<h1 class="w3-jumbo w3-animate-top">User Register</h1>
  	</header>
  	<br>
  	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">	
	<div class="container">
	    <div class="row">
	      <div class="col-25">
	        <label for="uname">User Name</label>
	      </div>
	      <div class="col-75">
	        <input type="text" id="username" name="username" placeholder="Your name..">
	      </div>
	    </div>
	    <div class="row">
	      <div class="col-25">
	        <label for="password">Password</label>
	      </div>
	      <div class="col-75">
	        <input type="password" id="pass" name="password">
	      </div>
	    </div>
	   
	    <div class="row w3-center">
	    	<a href="index.php" class="w3-button w3-grey w3-section" type="button">Back</a>
	      <button class="w3-button w3-green w3-section" type="submit" name="submit" id="submit">Sign Up</button>
	      
	    </div>
	</div>
	</form>
</body>
