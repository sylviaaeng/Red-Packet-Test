<?php
    // Include DB connect file
    require_once "dbConnect.php";
    require_once "header.php";
?>
<?php

	if(!isset($_SESSION)){
		session_start();
	}

		//checking the current user logged
	if(isset($_SESSION['isLogin']) && $_SESSION['isLogin']){
		header("location: index.php");
		exit();
	}
		
	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['uname'],$_POST['pass']) && !empty($_POST['uname']) && !empty($_POST['pass'])){
		$username = $_POST['uname'];
		$password = $_POST['pass'];
		
	//Check with database by using given username
	$sql = "SELECT`password`,`user_name` FROM `user` WHERE `user_name`=?";
	
		if($stmt = mysqli_prepare($conn,$sql)){
		mysqli_stmt_bind_param($stmt,"s",$username);
		
		mysqli_stmt_execute($stmt);
		
		mysqli_stmt_store_result($stmt);
		
		if(mysqli_stmt_num_rows($stmt) == 1){
			
			mysqli_stmt_bind_result($stmt,$c1,$c2);
			
			mysqli_stmt_fetch($stmt);
		
				if(password_verify($password,$c1)){
					echo"<script>alert('Login successfully');</script>";
					$_SESSION['isLogin'] = true;
					$_SESSION['username'] = $username;
					header("Location: index.php");
					exit();
				}
			}
			mysqli_stmt_free_result($stmt);
			mysqli_stmt_close($stmt);
		}
	}
?>
<body class="bgimg-login">
	<header class="w3-container w3-center w3-padding-16 w3-light-grey">  	
		<h1 class="w3-jumbo w3-animate-top">User Login</h1>
  	</header>
  	<br>
  	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
		<div class="container">
		    <div class="row">
		      	<div class="col-25">
		        	<label for="uname">User Name</label>
		      	</div>
		      	<div class="col-75">
		        	<input type="text" id="uname" name="uname" placeholder="Your name..">
		      	</div>
		    </div>
		    <div class="row">
		      	<div class="col-25">
		        	<label for="password">Password</label>
		      	</div>
		      	<div class="col-75">
		        	<input type="password" id="pass" name="pass">
		      	</div>
		    </div>
		    <div>
				<a href="register.php">Create new account?</a>
			</div>
		    <div class="row w3-center">
		    	<a href="index.php" class="w3-button w3-grey w3-section" type="button">Back</a>
		      	<button class="w3-button w3-green w3-section" type="submit">Sign In</button>
		    </div>
		</div>
	 </form>
</body>
